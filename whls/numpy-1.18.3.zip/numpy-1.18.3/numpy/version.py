
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.18.3'
version = '1.18.3'
full_version = '1.18.3'
git_revision = 'b07baa1e0ee0a4ca5dfd89bf51a0f57340b639b8'
release = True

if not release:
    version = full_version
