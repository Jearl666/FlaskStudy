.. _style_guide:

===================
NumPy C Style Guide
===================

.. include:: ../../C_STYLE_GUIDE.rst.txt
   :start-line: 4
